/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.birzeit.webservices.webservice;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/**
 *
 * @author Masoud
 */
@WebService(serviceName = "webserviceGet")
public class webserviceGet {


    /**
     * Web service operation
     */
    
   static ArrayList usersList = new ArrayList();
    
    @WebMethod(operationName = "getFriendList")
    public String getFriendList(@WebParam(name = "ID")int ID) {
        String friendsData;
        try {
            try {
                parsingJsonFile();
            } catch (JSONException ex) {
                Logger.getLogger(webserviceGet.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
            Logger.getLogger(webserviceGet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        User test = new User();
        test = (User)usersList.get(ID);
        return test.getFriendsList();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getLocation")
    public String getLocation(@WebParam(name = "ID") int ID) {
        Double x,y;
        User u;
        String address;
        String data;
     if(usersList.size() == 0){
            try {
            try {
                parsingJsonFile();
            } catch (JSONException ex) {
                Logger.getLogger(webserviceGet.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
            Logger.getLogger(webserviceGet.class.getName()).log(Level.SEVERE, null, ex);
        }
            u=(User)usersList.get(ID-1);
            x =u.getLocation().getX();
             y=u.getLocation().getY();
              address =u.getLocation().getAddress();
              data = new StringBuilder().append(x ).append(" , ").append(y).append("-->").append(address).toString();
     }else {
           u=(User)usersList.get(ID-1);
            x =u.getLocation().getX();
             y=u.getLocation().getY();
              address =u.getLocation().getAddress();
              data = new StringBuilder().append(x ).append(" , ").append(y).append("-->").append(address).toString();
     }
        return data;
    }
      
    
    private static JSONTokener jsonOut;
      private void parsingJsonFile() throws JSONException, IOException {
                      // user name -_- 
          File f = new File("C:\\Users\\Masoud\\Desktop\\assignment1\\assignment1\\assignment1\\src\\java\\edu\\birzeit\\webservices\\webservice\\users.json");

             String json = readFile(f.getPath());
              jsonOut = new JSONTokener(json);
       
         
         try {
        JSONObject output = new JSONObject(jsonOut);
       
        JSONArray array = output.getJSONArray("user");
                
        for(int i=0; i < array.length(); i++){
            JSONObject object = array.getJSONObject(i);
            
            User  user = new User();
            user.setId(Integer.parseInt( object.getString("id")));
         
         user.setName(object.getString("name"));
          
            
            String l =  object.getString("location");
            String[] parts = l.split(",");
            String x = parts[0]; 
            String y= parts[1];
            
            LocationData loc = new LocationData();
            loc.setX(Double.parseDouble(x));
            loc.setY(Double.parseDouble(y));
            
            loc.setAddress( object.getString("address"));
            user.setLocation(loc);
            
            String friends = new String();
            friends =  object.getString("freinds");
             user.setFriendsList(friends);
            usersList.add(user);
        }

       } catch (JSONException e) {
          e.printStackTrace();
       }
                         
            
         
         
            }
      
        private static String readFile(String file) throws IOException {
        
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = null;
        StringBuilder stringBuilder = new StringBuilder();
        String ls = System.getProperty("line.separator");

        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            stringBuilder.append(ls);
        }

        return stringBuilder.toString();
    }
}
